package com.java.jdbc.model;


public class Asset {

    private int assetId; // Primary Key
    private String assetType; // Asset Type (e.g., Laptop, Phone)
    private String assetName; // Asset Name
    private String model; // Model Name
    private double price; // Price of Asset
    private int quantity; // Quantity available

    // Default constructor
    public Asset() {
        super();
    }

    // Parameterized constructor
    public Asset(int assetId, String assetType, String assetName, String model, double price, int quantity) {
        this.assetId = assetId;
        this.assetType = assetType;
        this.assetName = assetName;
        this.model = model;
        this.price = price;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getAssetId() {
        return assetId;
    }

    public void setAssetId(int assetId) {
        this.assetId = assetId;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double d) {
        this.price = d;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Override toString method
    @Override
    public String toString() {
        return "Asset [assetId=" + assetId + ", assetType=" + assetType + ", assetName=" + assetName + ", model=" + model
                + ", price=" + price + ", quantity=" + quantity + "]";
    }
}
