package com.java.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.java.jdbc.model.Asset;
import com.java.jdbc.util.ConnectionHelper;

public class AssetDaoImp {

    Connection connection;
    PreparedStatement pst;

 
    public List<Asset> showAssetDao() throws ClassNotFoundException, SQLException {
        Asset asset = null;
        List<Asset> assetList = new ArrayList<>();
        connection = ConnectionHelper.getConnection();
        String cmd = "select * from Asset";
        pst = connection.prepareStatement(cmd);
        ResultSet rs = pst.executeQuery();
        while (rs.next()) {
            asset = new Asset();
            asset.setAssetId(rs.getInt("AssetId"));
            asset.setAssetType(rs.getString("AssetType"));
            asset.setAssetName(rs.getString("AssetName"));
            asset.setModel(rs.getString("Model"));
            asset.setPrice(rs.getDouble("Price"));
            asset.setQuantity(rs.getInt("Quantity"));
            assetList.add(asset);
        }
        return assetList;
    }

  
    public Asset searchAsset(int assetId) throws ClassNotFoundException, SQLException {
        Asset asset = null;
        connection = ConnectionHelper.getConnection();
        String cmd = "select * from Asset where AssetId = ?";
        pst = connection.prepareStatement(cmd);
        pst.setInt(1, assetId);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            asset = new Asset();
            asset.setAssetId(rs.getInt("AssetId"));
            asset.setAssetType(rs.getString("AssetType"));
            asset.setAssetName(rs.getString("AssetName"));
            asset.setModel(rs.getString("Model"));
            asset.setPrice(rs.getDouble("Price"));
            asset.setQuantity(rs.getInt("Quantity"));
        }
        return asset;
    }


    public String addAssetDao(Asset asset) throws ClassNotFoundException, SQLException {
        String cmd = "Insert into Asset(AssetId, AssetType, AssetName, Model, Price, Quantity) "
                + "values(?, ?, ?, ?, ?, ?)";
        connection = ConnectionHelper.getConnection();
        pst = connection.prepareStatement(cmd);
        pst.setInt(1, asset.getAssetId());
        pst.setString(2, asset.getAssetType());
        pst.setString(3, asset.getAssetName());
        pst.setString(4, asset.getModel());
        pst.setDouble(5, asset.getPrice());
        pst.setInt(6, asset.getQuantity());
        pst.executeUpdate();
        return "Asset Record Inserted...";
    }

 
    public String updateAssetDao(Asset asset) throws ClassNotFoundException, SQLException {
        Asset assetFound = searchAsset(asset.getAssetId());
        if (assetFound != null) {
            String cmd = "Update Asset set AssetType = ?, AssetName = ?, Model = ?, "
                    + "Price = ?, Quantity = ? Where AssetId = ?";
            connection = ConnectionHelper.getConnection();
            pst = connection.prepareStatement(cmd);
            pst.setString(1, asset.getAssetType());
            pst.setString(2, asset.getAssetName());
            pst.setString(3, asset.getModel());
            pst.setDouble(4, asset.getPrice());
            pst.setInt(5, asset.getQuantity());
            pst.setInt(6, asset.getAssetId());
            pst.executeUpdate();
            return "Asset Record Updated...";
        }
        return "Asset Record Not Found...";
    }


    public String deleteAssetDao(int assetId) throws ClassNotFoundException, SQLException {
        Asset assetFound = searchAsset(assetId);
        if (assetFound != null) {
            connection = ConnectionHelper.getConnection();
            String cmd = "delete from Asset where AssetId = ?";
            pst = connection.prepareStatement(cmd);
            pst.setInt(1, assetId);
            pst.executeUpdate();
            return "Asset Record Deleted...";
        }
        return "Asset Record Not Found...";
    }
    
    public Asset getAssetById(int assetId) throws SQLException, ClassNotFoundException {
        Asset asset = null;
        // Create your DB connection and logic to fetch the asset from the database by its ID
        // Example SQL query: SELECT * FROM assets WHERE assetId = ?
        
        // Sample code for fetching from the database:
        String sql = "SELECT * FROM assets WHERE assetId = ?";
        connection = ConnectionHelper.getConnection();
        String cmd = "delete from Asset where AssetId = ?";
        pst = connection.prepareStatement(cmd);
        pst.setInt(1, assetId);
        pst.executeUpdate();
        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                // Map the result set to an Asset object
                asset = new Asset();
                asset.setAssetId(rs.getInt("assetId"));
                asset.setAssetType(rs.getString("assetType"));
                asset.setAssetName(rs.getString("assetName"));
                asset.setModel(rs.getString("model"));
                asset.setPrice(rs.getDouble("price"));
                asset.setQuantity(rs.getInt("quantity"));
            }
        }
        
        return asset;
    }
}
