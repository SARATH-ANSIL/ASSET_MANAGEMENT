//package com.java.jdbc.dao;
//
//import java.sql.SQLException;
//import java.util.List;
//
//import com.java.jdbc.model.EmployNew;
//
//public interface EmployDao {
//
//	List<EmployNew> showEmployDao() throws ClassNotFoundException, SQLException;
//	EmployNew searchEmploy(int empno) throws ClassNotFoundException, SQLException;
//	String addEmployDao(EmployNew employ) throws ClassNotFoundException, SQLException;
//	String updateEmployDao(EmployNew employ) throws ClassNotFoundException, SQLException;
//	String deleteEmployDao(int empno) throws ClassNotFoundException, SQLException;
//}
package com.java.jdbc.dao;

import java.sql.SQLException;
import java.util.List;
import com.java.jdbc.model.Asset;

public interface AssetDao {

    // Show all assets
    List<Asset> showAssetDao() throws ClassNotFoundException, SQLException;

    // Search for an asset by asset ID
    Asset searchAsset(int assetId) throws ClassNotFoundException, SQLException;

    // Add a new asset to the database
    String addAssetDao(Asset asset) throws ClassNotFoundException, SQLException;

    // Update asset details in the database
    String updateAssetDao(Asset asset) throws ClassNotFoundException, SQLException;

    // Delete an asset by asset ID
    String deleteAssetDao(int assetId) throws ClassNotFoundException, SQLException;
    Asset getAssetById(int assetId) throws SQLException, ClassNotFoundException;
}
