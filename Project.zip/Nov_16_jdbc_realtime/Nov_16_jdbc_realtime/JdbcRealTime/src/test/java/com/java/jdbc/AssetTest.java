package com.java.jdbc;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.Test;

import com.java.jdbc.dao.*;
import com.java.jdbc.model.Asset;

public class AssetTest {

    @Test
    public void testDefaultConstructor() {
        Asset asset = new Asset();
        assertNotNull("Asset should not be null", asset);
        assertEquals("Price should be default to 0", 0.0, asset.getPrice(), 0.001);
        assertEquals("Quantity should be default to 0", 0, asset.getQuantity());
    }

    @Test
    public void testParameterizedConstructor() {
        Asset asset = new Asset(1, "Laptop", "Dell Inspiron", "Inspiron 15", 750.50, 10);
        assertNotNull("Asset should not be null", asset);
        assertEquals("Asset ID should match", 1, asset.getAssetId());
        assertEquals("Asset Type should match", "Laptop", asset.getAssetType());
        assertEquals("Asset Name should match", "Dell Inspiron", asset.getAssetName());
        assertEquals("Model should match", "Inspiron 15", asset.getModel());
        assertEquals("Price should match", 750.50, asset.getPrice(), 0.001);
        assertEquals("Quantity should match", 10, asset.getQuantity());
    }

    @Test
    public void testGettersAndSetters() {
        Asset asset = new Asset();
        asset.setAssetId(2);
        asset.setAssetType("Phone");
        asset.setAssetName("iPhone 14");
        asset.setModel("iPhone 14 Pro");
        asset.setPrice(999.99);
        asset.setQuantity(5);

        assertEquals("Asset ID should match", 2, asset.getAssetId());
        assertEquals("Asset Type should match", "Phone", asset.getAssetType());
        assertEquals("Asset Name should match", "iPhone 14", asset.getAssetName());
        assertEquals("Model should match", "iPhone 14 Pro", asset.getModel());
        assertEquals("Price should match", 999.99, asset.getPrice(), 0.001);
        assertEquals("Quantity should match", 5, asset.getQuantity());
    }

    @Test
    public void testToString() {
        Asset asset = new Asset(3, "Tablet", "iPad", "iPad Air", 499.00, 15);
        String expected = "Asset [assetId=3, assetType=Tablet, assetName=iPad, model=iPad Air, price=499.0, quantity=15]";
        assertEquals("ToString should match expected format", expected, asset.toString());
    }

    @Test
    public void testPriceSetterValidation() {
        Asset asset = new Asset();

        asset.setPrice(1500.00);
        assertEquals("Price should be set correctly", 1500.00, asset.getPrice(), 0.001);

        asset.setPrice(0.00);
        assertEquals("Price should be set to 0 correctly", 0.00, asset.getPrice(), 0.001);

        asset.setPrice(-50.00);
        assertEquals("Price should allow negative values", -50.00, asset.getPrice(), 0.001);
    }

    @Test
    public void testNegativeQuantity() {
        Asset asset = new Asset();
        asset.setQuantity(-5);
        assertEquals("Quantity should allow negative values", -5, asset.getQuantity());
    }

    @Test
    public void testEdgeCasePrice() {
        Asset asset = new Asset();
        asset.setPrice(0.01);
        assertEquals("Price should handle small values correctly", 0.01, asset.getPrice(), 0.001);
    }

    @Test
    public void testLargeValues() {
        Asset asset = new Asset(99999, "Server", "High-end Server", "SuperServer X12", 1000000.00, 10000);
        assertEquals("Asset ID should handle large values", 99999, asset.getAssetId());
        assertEquals("Asset Type should match", "Server", asset.getAssetType());
        assertEquals("Price should handle large values", 1000000.00, asset.getPrice(), 0.001);
        assertEquals("Quantity should handle large values", 10000, asset.getQuantity());
    }

 
//    @Test
//    public void testAssetFromDatabase() {
//        int assetId = 1; 
//        AssetDaoImp assetDAO = new AssetDaoImp();  
//
//        try {
//            Asset asset = assetDAO.getAssetById(assetId);
//
//            double expectedPrice = 750.50;
//            int expectedQuantity = 10;
//
//            assertNotNull("Asset should not be null", asset);
//            assertEquals("Price should match the expected value", expectedPrice, asset.getPrice(), 0.001);
//            assertEquals("Quantity should match the expected value", expectedQuantity, asset.getQuantity());
//            assertEquals("Asset ID should match", assetId, asset.getAssetId());
//
//        } catch (SQLException | ClassNotFoundException e) {
//            e.printStackTrace();
//            fail("Database connection failed or asset retrieval failed");
//        }
//    }

}
